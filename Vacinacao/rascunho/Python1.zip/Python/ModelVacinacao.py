#from _typeshed import Self
import psycopg2
##class ModelVacinacao:
host = 'localhost'
dbname = 'Vacinacao'
user = 'postgres'
password = '1234'
sslmode = 'require'
conn_string = "host={0} user={1} dbname={2} password={3}".format(host, user, dbname, password)
conn = psycopg2.connect(conn_string)
print('conectado')
cursor = conn.cursor()

def criarTabela():
    cursor.execute("CREATE TABLE documento(id serial PRIMARY KEY,timestamp VARCHAR(50),paciente_idade INTEGER, paciente_endereco_nmMunicipio VARCHAR(64), vacina_descricao_dose VARCHAR(50), vacina_fabricante_nome varchaR(64), vacina_categoria_nome VARCHAR(50),vacina_nome VARCHAR(64), paciente_enumSexoBiologico VARCHAR(1));")

def addPaciente(cursor,timestamp, paciente_idade, paciente_endereco_nmMunicipio, vacina_descricao_dose, vacina_fabricante_nome, vacina_categoria_nome, vacina_nome,paciente_enumSexoBiologico,id):
    cursor.execute("INSERT INTO documento (timestamp, paciente_idade, paciente_endereco_nmMunicipio, vacina_descricao_dose, vacina_fabricante_nome, vacina_categoria_nome, vacina_nome,paciente_enumSexoBiologico, id) VALUES (%s,%s, %s,%s,%s,%s,%s,%s,%s);", (timestamp, paciente_idade, paciente_endereco_nmMunicipio, vacina_descricao_dose, vacina_fabricante_nome, vacina_categoria_nome, vacina_nome,paciente_enumSexoBiologico, id))
    print('adicionado --'+ timestamp + str("--" +id))

def selecionarTotalCadastrado():
    cursor.execute("SELECT COUNT(*) FROM documento")
    rows = cursor.fetchall()
    return rows
def selecionarPorSexoMasculino():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_enumSexoBiologico = 'M'")
    rows = cursor.fetchall()
    return rows
def selecionarPorSexoFeminino():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_enumSexoBiologico = 'F'")
    rows = cursor.fetchall()
    return rows
def selecionarPorCidade(cidade):
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_endereco_nmMunicipio ='"+cidade+"';")
    rows = cursor.fetchall()
    return rows
def selecionarPorIdade18a24():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_idade >= 18 and paciente_idade <= 24")
    rows = cursor.fetchall()
    return rows
def selecionarPorIdade25a60():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_idade >= 25 and paciente_idade <= 60")
    rows = cursor.fetchall()
    return rows
def selecionarPorIdadeMaiorQue61():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE paciente_idade >= 61")
    rows = cursor.fetchall()
    return rows
def selecionarPrimeiraDose():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE vacina_descricao_dose = '1ª Dose'")
    rows = cursor.fetchall()
    return rows
def selecionarSegundaDose():
    cursor.execute("SELECT COUNT(*) FROM documento WHERE vacina_descricao_dose = '2ª Dose'")
    rows = cursor.fetchall()
    return rows

#sicronizar dados com a tabela
def sicronizar_vacina_aplicada():
    resposta = selecionarTotalCadastrado()
    totalM = selecionarPorSexoMasculino()
    totalF = selecionarPorSexoFeminino()
    totalIdade18a24 = selecionarPorIdade18a24()
    totalIdade25a60 = selecionarPorIdade25a60()
    totalIdadeMaiorque61 = selecionarPorIdadeMaiorQue61()
    totalPrimeiradose = selecionarPrimeiraDose()
    totalSegundadose = selecionarSegundaDose()
    #cmd sql
    cursor.execute("INSERT INTO vacina_aplicada (total_habitante_ibge, total, total_feminino, total_masculino, total_primeira_dose, total_segunda_dose, total_idade_18a24, total_idade_25a60, total_idade_maiorque61, data_de_sicronizacao) VALUES (3534165,%s,%s, %s,%s,%s,%s,%s,%s,now());",(resposta[0],totalF[0],totalM[0],totalPrimeiradose[0],totalSegundadose[0],totalIdade18a24[0],totalIdade25a60[0],totalIdadeMaiorque61[0]))
    fecharConexao(conn,cursor)
    print("atualizado")

def pega_ultimo_dado():
    cursor.execute("SELECT timestamp FROM documento order by timestamp DESC LIMIT 1")
    rows = cursor.fetchall()
    return rows


    #criarTabela()
def getPegarConexao():
    return  cursor
def getPegarOConn():
    return conn

def fecharConexao(conn,cursor):
    conn.commit()
    #cursor.close()
    #conn.close()

#sicronizar_vacina_aplicada()
    #fecharConexao(conn,cursor)
#addPaciente(cursor,'12/12/12',18,'nc','vicinacao','nome da vacincao','fabricante','categoria','m','idid')
#fecharConexao(conn,cursor)
#fecharConexao()
