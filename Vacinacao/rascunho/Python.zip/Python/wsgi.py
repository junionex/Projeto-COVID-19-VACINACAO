from API import app

if __name__ == "__main":
    app.run()